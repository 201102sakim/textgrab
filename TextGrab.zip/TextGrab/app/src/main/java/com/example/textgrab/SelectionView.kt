package com.example.textgrab

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** 한 손가락 드래그로 박스 생성, 모서리(크기)/안쪽(이동) 조절 */
class SelectionView(c: Context) : View(c) {
    var rect: RectF? = null
    private val d = resources.displayMetrics.density
    private val hit = 40 * d
    private val dim = Paint().apply { color = 0x33000000 }
    private val fill = Paint().apply { color = 0x2266AAFF }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF3399FF.toInt(); style = Paint.Style.STROKE; strokeWidth = 3 * d }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 16 * d; textAlign = Paint.Align.CENTER; setShadowLayer(4f, 0f, 0f, Color.BLACK) }
    private var mode = 0 // 1~4 모서리, 5 이동, 6 새로 그리기
    private var lx = 0f; private var ly = 0f

    private fun near(x: Float, y: Float, px: Float, py: Float) = abs(x - px) < hit && abs(y - py) < hit

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lx = e.x; ly = e.y
                val r = rect
                mode = when {
                    r != null && near(lx, ly, r.left, r.top) -> 1
                    r != null && near(lx, ly, r.right, r.top) -> 2
                    r != null && near(lx, ly, r.left, r.bottom) -> 3
                    r != null && near(lx, ly, r.right, r.bottom) -> 4
                    r != null && r.contains(lx, ly) -> 5
                    else -> 6 // 새 박스 생성
                }
                if (mode == 6) rect = RectF(lx, ly, lx, ly)
            }
            MotionEvent.ACTION_MOVE -> {
                val r = rect ?: return true
                val dx = e.x - lx; val dy = e.y - ly; lx = e.x; ly = e.y
                when (mode) {
                    1 -> { r.left += dx; r.top += dy }
                    2 -> { r.right += dx; r.top += dy }
                    3 -> { r.left += dx; r.bottom += dy }
                    4 -> { r.right += dx; r.bottom += dy }
                    5 -> r.offset(dx, dy)
                    6 -> { r.right = e.x; r.bottom = e.y }
                }
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                rect?.let { it.sort(); if (it.width() < 20 * d || it.height() < 20 * d) rect = null }
                mode = 0; invalidate()
            }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)
        val r = rect
        if (r == null) { c.drawText("한 손가락으로 드래그해 영역 지정", width / 2f, height / 2f, txt); return }
        c.drawRect(r, fill); c.drawRect(r, line)
        for ((x, y) in listOf(r.left to r.top, r.right to r.top, r.left to r.bottom, r.right to r.bottom))
            c.drawCircle(x, y, 8 * d, dot)
    }
}
