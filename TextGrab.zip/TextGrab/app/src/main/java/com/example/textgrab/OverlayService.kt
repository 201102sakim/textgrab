package com.example.textgrab

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.IntentCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var panel: LinearLayout
    private lateinit var menu: LinearLayout
    private lateinit var tab: TextView
    private lateinit var panelLp: LP
    private var sel: SelectionView? = null
    private var proj: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private val h = Handler(Looper.getMainLooper())
    @Volatile private var want = false
    private var sw = 0; private var sh = 0
    private val ocr by lazy { TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()) }

    override fun onBind(i: Intent?): IBinder? = null
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onStartCommand(i: Intent, f: Int, s: Int): Int {
        if (proj != null) return START_NOT_STICKY
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("tg", "글자 복사", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "tg").setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("글자 복사 실행 중").build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        wm = getSystemService(WindowManager::class.java)
        val b = wm.maximumWindowMetrics.bounds; sw = b.width(); sh = b.height()
        val data = IntentCompat.getParcelableExtra(i, "data", Intent::class.java)!!
        proj = getSystemService(MediaProjectionManager::class.java).getMediaProjection(i.getIntExtra("code", 0), data)
        proj!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, h)
        reader = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2).apply {
            setOnImageAvailableListener({ r ->
                val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
                if (!want) { img.close(); return@setOnImageAvailableListener }
                want = false
                val p = img.planes[0]
                val bmp = Bitmap.createBitmap(p.rowStride / p.pixelStride, sh, Bitmap.Config.ARGB_8888)
                bmp.copyPixelsFromBuffer(p.buffer); img.close()
                recognize(bmp)
            }, h)
        }
        vd = proj!!.createVirtualDisplay("tg", sw, sh, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)
        buildPanel()
        return START_NOT_STICKY
    }

    private fun btn(t: String, a: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 14f
        setPadding(dp(14), dp(10), dp(14), dp(10)); setBackgroundColor(0xDD222222.toInt())
        setOnClickListener { a() }
    }

    /** 오른쪽 가장자리 툴 탭: 누르면 메뉴가 펼쳐짐 */
    private fun buildPanel() {
        menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            addView(btn("📋 복사") { copyText() })
            addView(btn("✕ 종료") { stopSelf() })
        }
        tab = btn("◀") { setOpen(menu.visibility == View.GONE) }
        panel = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(tab); addView(menu) }
        panelLp = LP(LP.WRAP_CONTENT, LP.WRAP_CONTENT, LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.END or Gravity.TOP; y = sh / 3 }
        wm.addView(panel, panelLp)
    }

    /** ◀ 누르면 메뉴가 펼쳐지고 박스 생성 시작, ▶ 누르면 접히고 박스 모드 종료 */
    private fun setOpen(open: Boolean) {
        menu.visibility = if (open) View.VISIBLE else View.GONE
        tab.text = if (open) "▶" else "◀"
        if (open != (sel != null)) toggleSelect()
    }

    private fun toggleSelect() {
        val s = sel
        if (s != null) { wm.removeView(s); sel = null; return }
        val v = SelectionView(this)
        wm.addView(v, LP(LP.MATCH_PARENT, LP.MATCH_PARENT, LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT))
        sel = v
        wm.removeView(panel); wm.addView(panel, panelLp) // 툴 패널을 항상 맨 위로
    }

    private fun copyText() {
        val s = sel; if (s?.rect == null) { toast("◀ 버튼을 누르고 드래그해 영역을 먼저 지정하세요"); return }
        s.visibility = View.INVISIBLE; panel.visibility = View.INVISIBLE // 캡처에 안 찍히게 숨김
        h.postDelayed({ want = true }, 200)
        h.postDelayed({ if (want) { want = false; restore(); toast("캡처 실패, 다시 시도하세요") } }, 2000)
    }

    private fun restore() { sel?.visibility = View.VISIBLE; panel.visibility = View.VISIBLE }

    private fun recognize(full: Bitmap) {
        val s = sel ?: return restore()
        val r = RectF(s.rect ?: return restore()); val loc = IntArray(2); s.getLocationOnScreen(loc)
        r.offset(loc[0].toFloat(), loc[1].toFloat())
        restore()
        val x = r.left.toInt().coerceIn(0, sw - 1); val y = r.top.toInt().coerceIn(0, sh - 1)
        val crop = Bitmap.createBitmap(full, x, y, r.width().toInt().coerceIn(1, sw - x), r.height().toInt().coerceIn(1, sh - y))
        ocr.process(InputImage.fromBitmap(crop, 0)).addOnSuccessListener {
            if (it.text.isBlank()) toast("글자를 찾지 못했어요") else {
                getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("textgrab", it.text))
                toast("복사됨: " + it.text.take(30))
            }
        }.addOnFailureListener { toast("인식 실패") }
    }

    override fun onDestroy() {
        sel?.let { wm.removeView(it) }; if (::panel.isInitialized) wm.removeView(panel)
        vd?.release(); reader?.close(); proj?.stop(); ocr.close()
        super.onDestroy()
    }
}
