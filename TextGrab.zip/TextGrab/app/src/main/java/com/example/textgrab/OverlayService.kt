package com.example.textgrab

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.IntentCompat
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var panel: LinearLayout
    private lateinit var menu: LinearLayout
    private lateinit var tab: TextView
    private lateinit var trBtn: TextView
    private lateinit var passBtn: TextView
    private var pass = false
    private var selLp: LP? = null
    private lateinit var panelLp: LP
    private var sel: SelectionView? = null
    private var proj: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private val h = Handler(Looper.getMainLooper())
    @Volatile private var want = false
    private var translateOn = false
    private var sw = 0; private var sh = 0
    private var downY = 0f; private var startY = 0; private var moved = false
    // 한글·일본어·중국어(한자) 인식기를 모두 돌려 가장 확신도 높은 결과 선택 (셋 다 영문 포함)
    private val recs by lazy { listOf(
        TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()),
        TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build()),
        TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())) }
    private val cjk = Regex("[\\u3040-\\u30FF\\u4E00-\\u9FFF]")

    override fun onBind(i: Intent?): IBinder? = null
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onStartCommand(i: Intent, f: Int, s: Int): Int {
        if (proj != null) return START_NOT_STICKY
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("tg", "글자 복사", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "tg").setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("글자 복사 실행 중").build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        wm = getSystemService(WindowManager::class.java)
        val b = wm.maximumWindowMetrics.bounds; sw = b.width(); sh = b.height()
        val data = IntentCompat.getParcelableExtra(i, "data", Intent::class.java)!!
        proj = getSystemService(MediaProjectionManager::class.java).getMediaProjection(i.getIntExtra("code", 0), data)
        proj!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, h)
        reader = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2).apply {
            setOnImageAvailableListener({ r ->
                val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
                if (!want) { img.close(); return@setOnImageAvailableListener }
                want = false
                val p = img.planes[0]
                val bmp = Bitmap.createBitmap(p.rowStride / p.pixelStride, sh, Bitmap.Config.ARGB_8888)
                bmp.copyPixelsFromBuffer(p.buffer); img.close()
                recognize(bmp)
            }, h)
        }
        vd = proj!!.createVirtualDisplay("tg", sw, sh, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)
        buildPanel()
        return START_NOT_STICKY
    }

    private fun btn(t: String, a: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 14f
        setPadding(dp(14), dp(10), dp(14), dp(10)); setBackgroundColor(0xDD222222.toInt())
        setOnClickListener { a() }
    }

    private fun buildPanel() {
        trBtn = btn("🌐 번역: 꺼짐") {
            translateOn = !translateOn
            trBtn.text = if (translateOn) "🌐 번역: 켜짐" else "🌐 번역: 꺼짐"
        }
        passBtn = btn("🔍 확대/축소: 꺼짐") { setPass(!pass) }
        menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            addView(btn("📋 복사") { copyText() })
            addView(passBtn)
            addView(trBtn)
            addView(btn("✕ 종료") { stopSelf() })
        }
        tab = btn("◀") {}
        tab.setOnTouchListener { _, e -> dragTab(e) } // 탭: 열기/닫기, 위아래 드래그: 위치 이동
        panel = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(tab); addView(menu) }
        panelLp = LP(LP.WRAP_CONTENT, LP.WRAP_CONTENT, LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.END or Gravity.TOP; y = sh / 3 }
        wm.addView(panel, panelLp)
    }

    private fun dragTab(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downY = e.rawY; startY = panelLp.y; moved = false }
            MotionEvent.ACTION_MOVE -> {
                val dy = e.rawY - downY
                if (abs(dy) > dp(8)) moved = true
                if (moved) {
                    panelLp.y = (startY + dy).toInt().coerceIn(0, (sh - panel.height).coerceAtLeast(0))
                    wm.updateViewLayout(panel, panelLp)
                }
            }
            MotionEvent.ACTION_UP -> if (!moved) setOpen(menu.visibility == View.GONE)
        }
        return true
    }

    /** ◀ 누르면 메뉴가 펼쳐지고 박스 생성 시작, ▶ 누르면 접히고 박스 모드 종료 */
    private fun setOpen(open: Boolean) {
        menu.visibility = if (open) View.VISIBLE else View.GONE
        tab.text = if (open) "▶" else "◀"
        if (open != (sel != null)) toggleSelect()
    }

    private fun toggleSelect() {
        val s = sel
        if (s != null) {
            wm.removeView(s); sel = null; selLp = null
            pass = false; passBtn.text = "🔍 확대/축소: 꺼짐"; return
        }
        val v = SelectionView(this)
        val lp = LP(LP.MATCH_PARENT, LP.MATCH_PARENT, LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        selLp = lp; wm.addView(v, lp); sel = v
        wm.removeView(panel); wm.addView(panel, panelLp)
    }

    /** 켜면 박스는 보이되 터치가 아래 앱으로 통과해 핀치 확대/축소·스크롤이 가능 */
    private fun setPass(on: Boolean) {
        val lp = selLp ?: return
        pass = on
        lp.flags = if (on) lp.flags or LP.FLAG_NOT_TOUCHABLE else lp.flags and LP.FLAG_NOT_TOUCHABLE.inv()
        wm.updateViewLayout(sel, lp)
        passBtn.text = if (on) "🔍 확대/축소: 켜짐" else "🔍 확대/축소: 꺼짐"
    }

    private fun copyText() {
        val s = sel; if (s?.rect == null) { toast("◀ 버튼을 누르고 드래그해 영역을 먼저 지정하세요"); return }
        s.visibility = View.INVISIBLE; panel.visibility = View.INVISIBLE
        h.postDelayed({ want = true }, 200)
        h.postDelayed({ if (want) { want = false; restore(); toast("캡처 실패, 다시 시도하세요") } }, 2000)
    }

    private fun restore() { sel?.visibility = View.VISIBLE; panel.visibility = View.VISIBLE }

    private fun recognize(full: Bitmap) {
        val s = sel ?: return restore()
        val r = RectF(s.rect ?: return restore()); val loc = IntArray(2); s.getLocationOnScreen(loc)
        r.offset(loc[0].toFloat(), loc[1].toFloat())
        restore()
        val pad = dp(4) // 가장자리 글자 잘림 방지
        val x0 = (r.left.toInt() - pad).coerceIn(0, sw - 1); val y0 = (r.top.toInt() - pad).coerceIn(0, sh - 1)
        val x1 = (r.right.toInt() + pad).coerceIn(x0 + 1, sw); val y1 = (r.bottom.toInt() + pad).coerceIn(y0 + 1, sh)
        var crop = Bitmap.createBitmap(full, x0, y0, x1 - x0, y1 - y0)
        val sc = (200f / crop.height).coerceIn(1f, 3f) // 작은 글자는 확대해서 인식률 향상
        if (sc > 1.05f) crop = Bitmap.createScaledBitmap(crop, (crop.width * sc).toInt(), (crop.height * sc).toInt(), true)
        val img = InputImage.fromBitmap(crop, 0)
        Tasks.whenAllSuccess<Text>(recs.map { it.process(img) }).addOnSuccessListener { list ->
            val best = list.maxByOrNull { score(it) }
            val text = best?.let { format(it) } ?: ""
            if (text.isBlank()) toast("글자를 찾지 못했어요") else done(text)
        }.addOnFailureListener { toast("인식 실패") }
    }

    private fun score(t: Text) = t.textBlocks.flatMap { it.lines }.sumOf { (it.confidence * it.text.length).toDouble() }

    /** 줄바꿈으로 끊긴 문장을 다시 이어붙임: 문장부호로 끝나면 줄바꿈, 한자/일본어끼리는 붙이고 나머지는 공백 */
    private fun format(t: Text) = t.textBlocks.joinToString("\n") { b ->
        val sb = StringBuilder()
        for (l in b.lines) {
            val s = l.text.trim(); if (s.isEmpty()) continue
            if (sb.isNotEmpty()) {
                val p = sb.last()
                sb.append(when {
                    p in ".!?。！？…:" -> "\n"
                    cjk.matches(p.toString()) && cjk.matches(s[0].toString()) -> ""
                    else -> " "
                })
            }
            sb.append(s)
        }
        sb.toString()
    }

    private fun copy(t: String, prefix: String) {
        getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("textgrab", t))
        toast(prefix + t.take(30))
    }

    private fun done(text: String) {
        if (!translateOn) return copy(text, "복사됨: ")
        LanguageIdentification.getClient().identifyLanguage(text).addOnSuccessListener { tag ->
            val src = TranslateLanguage.fromLanguageTag(tag)
            if (src == null) return@addOnSuccessListener copy(text, "언어 판별 실패, 원문 복사: ")
            val dst = if (src == TranslateLanguage.KOREAN) TranslateLanguage.ENGLISH else TranslateLanguage.KOREAN
            val tr = Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(dst).build())
            toast("번역 중... (처음엔 언어 데이터를 내려받아요)")
            tr.downloadModelIfNeeded().continueWithTask { tr.translate(text) }
                .addOnSuccessListener { copy(it, "번역·복사됨: ") }
                .addOnFailureListener { copy(text, "번역 실패, 원문 복사: ") }
                .addOnCompleteListener { tr.close() }
        }.addOnFailureListener { copy(text, "원문 복사: ") }
    }

    override fun onDestroy() {
        sel?.let { wm.removeView(it) }; if (::panel.isInitialized) wm.removeView(panel)
        vd?.release(); reader?.close(); proj?.stop(); recs.forEach { it.close() }
        super.onDestroy()
    }
}
